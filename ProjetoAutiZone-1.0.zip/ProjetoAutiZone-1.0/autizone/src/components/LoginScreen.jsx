import React, { useState } from "react";
import "./LoginScreen.css";
import logo from "../assets/Autizone.png"; // importa a logo

export default function LoginScreen({ login }) {
  const [senha, setSenha] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    if (senha === "123") login();
    else alert("Senha incorreta! Tente novamente.");
  };

  return (
    <div className="login-container">
      {/* Logo fora do card */}
      <img src={logo} alt="AutiZone Logo" className="login-logo" />

      <div className="login-card">
        <form onSubmit={handleLogin} className="login-form">
          <input
            type="password"
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className="login-input"
          />
          <button type="submit" className="login-btn">
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
}
